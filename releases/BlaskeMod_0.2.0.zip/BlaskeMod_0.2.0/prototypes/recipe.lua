data:extend(
  {
    {
      type = "recipe",
      name = "steel-shovel",
      enabled = false,
      ingredients =
      {
        {"steel-plate", 5},
        {"iron-stick", 2},
        {"wood", 4}
      },
      result = "steel-shovel"
    }
  }
)